package com.example.presentacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class Partners extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partners);
    }
}

 class Partner{
     private String nombre;
     private String apellido;
     private String empresa;
     private String direccion;
     private String poblacion;
     private String telf;
     private static final String DIR_ARCHIVO = "C:\\Users\\inigo\\OneDrive\\Escritorio\\CEBANC2\\Javi\\Presentacion\\app\\src\\main\\res\\xml\\partners.xml";

     public Partner() {

     }

     public Partner(String nombre, String apellido, String empresa, String direccion, String poblacion, String telf) {
         this.nombre = nombre;
         this.apellido = apellido;
         this.empresa = empresa;
         this.direccion = direccion;
         this.poblacion = poblacion;
         this.telf = telf;
     }


     public String getNombre() {
         return nombre;
     }
     public void setNombre(String nombre) {
         this.nombre = nombre;
     }

     public String getApellido() {
         return apellido;
     }
     public void setApellido(String apellido) {
         this.apellido = apellido;
     }

     public String getEmpresa() {
         return empresa;
     }
     public void setEmpresa(String empresa) {
         this.empresa = empresa;
     }

     public String getDireccion() {
         return direccion;
     }
     public void setDireccion(String direccion) {
         this.direccion = direccion;
     }

     public String getPoblacion() {
         return poblacion;
     }
     public void setPoblacion(String poblacion) {
         this.poblacion = poblacion;
     }

     public String getTelf() {
         return telf;
     }
     public void setTelf(String telf) {
         this.telf = telf;
     }

     @Override
     public String toString() {
         return "Partner [\n\tnombre = " + nombre + ", apellido = " + apellido + ", \n\tempresa = " + empresa+ ", telf = " + telf + ", \n\tdireccion = "
                 + direccion + ", poblacion = " + poblacion + "\n]";
     }

     public ArrayList<Partner> leerXml() {
         ArrayList<Partner> partnersTemp = new ArrayList<Partner>();
         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
         try {
             // optional, but recommended
             // process XML securely, avoid attacks like XML External Entities (XXE)
             dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

             // transformar el XML file (parsear)
             DocumentBuilder db = dbf.newDocumentBuilder();

             Document doc = db.parse(new File(DIR_ARCHIVO));

             // optional, but recommended
             // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
             // corrige errores de indentación... del xml
             doc.getDocumentElement().normalize();

             System.out.println("Root Element:" + doc.getDocumentElement().getNodeName().toUpperCase());

             // Identificar los elementos llamados partner y almacenarlos en una lista
             NodeList listaPartners = doc.getElementsByTagName("partner");

             // El length devuelve la cantidad de items dentro de la lista
             for (int cualItem = 0; cualItem < listaPartners.getLength(); cualItem++) {

                 //Sacamos 1 item para tratarlo separado
                 Node node = listaPartners.item(cualItem);

                 if (node.getNodeType() == Node.ELEMENT_NODE) {
                     // Tratarlo como elemento
                     Element element = (Element) node;
                     Partner cliente;
                     String nombre, apellido, empresa, direccion, poblacion, telf;
                     double tot_fac;
                     int comercial;


                     nombre = element.getElementsByTagName("nombre").item(0).getTextContent();
                     apellido = element.getElementsByTagName("apellidos").item(0).getTextContent();
                     empresa = element.getElementsByTagName("empresa").item(0).getTextContent();
                     direccion = element.getElementsByTagName("direccion1").item(0).getTextContent();
                     poblacion = element.getElementsByTagName("poblacion").item(0).getTextContent();
                     telf = element.getElementsByTagName("telefono").item(0).getTextContent();

                     // Crear el objeto
                     cliente = new Partner(nombre, apellido, empresa, direccion, poblacion, telf);



                     partnersTemp.add(cliente);
                 }
             }

         } catch (ParserConfigurationException ep) {
             System.err.println("ERROR. Configuración de parse incorrecta.");
         } catch (IOException eio) {
             System.err.println("ERROR. Fallo en lectura de archivo.");
         } catch (SAXException esax) {
             System.err.println("ERROR. SAX exception.");
         } catch (NullPointerException en) {
             System.err.println("ERROR. Probablemente las etiquetas del XML no coinciden con los puestos en en el fichero java.");
         }
         return partnersTemp;
     }
}
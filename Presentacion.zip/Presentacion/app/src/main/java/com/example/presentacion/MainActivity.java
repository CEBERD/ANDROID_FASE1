package com.example.presentacion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// Implement OnMapReadyCallback.
public class MainActivity extends AppCompatActivity{

    TextView delegacion, direccion, tlfono, correo;
    Button cita, envio, partner, pedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout file as the content view.
        setContentView(R.layout.activity_main);

        delegacion = findViewById(R.id.txvDelegacion);
        direccion = findViewById(R.id.txvDireccion);
        tlfono = findViewById(R.id.txvTlfono);
        correo = findViewById(R.id.txvEmail);
        cita = findViewById(R.id.btnCalendario);
        envio = findViewById(R.id.btnEnvio);
        partner = findViewById(R.id.btnPartners);
        pedido = findViewById(R.id.btnPedidos);


        tlfono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+tlfono.toString()));
                startActivity(intent);
            }
        });

        correo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setData(Uri.parse("mailto:"+correo.toString()));
                startActivity(intent);
            }
        });

        cita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Citas.class);
                startActivity(intent);
            }
        });

        envio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Envios.class);
                startActivity(intent);
            }
        });

        partner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Partners.class);
            }
        });

    }
}
package com.example.presentacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Citas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citas);
    }
}

public class Cita {

    private String cita;
    private String comercial;
    private String fecha;
    private String asunto;
    private String descripcion;
    private String direccion;
    private String numero;
    private String planta;
    private String detalles;

    public Cita(String cita, String comercial, String fecha, String asunto, String descripcion, String direccion, String numero, String planta, String detalles) {
        this.cita = cita;
        this.comercial = comercial;
        this.fecha = fecha;
        this.asunto = asunto;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.numero = numero;
        this.planta = planta;
        this.detalles = detalles;
    }

    public String getCita() {
        return cita;
    }

    public void setCita(String cita) {
        this.cita = cita;
    }

    public String getComercial() {
        return comercial;
    }

    public void setComercial(String comercial) {
        this.comercial = comercial;
    }

    public String getfecha() {
        return fecha;
    }

    public void setfecha(String fecha) {
        this.fecha = fecha;
    }


    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }


    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getPlanta() {
        return planta;
    }

    public void setPlanta(String planta) {
        this.planta = planta;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    @Override
    public String toString() {
        return "Comercial [\n\tcodigo = " + comercial + ", nº cita = " + cita + "fecha = " + fecha + ", \n\tasunto = " + asunto + ", descripcion = " + descripcion + ", \n\tubicacion: "
                + "\n\t direccion = " + direccion + ", numero = " + numero + ", planta = " + planta + ", detalles = " + detalles + "\n]";
    }
}